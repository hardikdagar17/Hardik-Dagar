import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import './globals.css'

export const metadata: Metadata = { title: 'RakshaWell | Personnel Welfare Monitoring', description: 'AI-powered welfare monitoring for CAPF personnel.', generator: 'v0.app' }
export const viewport: Viewport = { colorScheme: 'dark', themeColor: '#030712', userScalable: false }

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en" className="bg-[#030712]"><body className="antialiased">{children}{process.env.NODE_ENV === 'production' && <Analytics />}</body></html>
}
