import RakshaWell from '@/components/rakshawell-dashboard'

export default function Page() {
  return <RakshaWell />
}
